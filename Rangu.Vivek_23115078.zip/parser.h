#pragma once
#include <string>
#include <vector>

std::string parse(const std::vector<std::string>& tokens);