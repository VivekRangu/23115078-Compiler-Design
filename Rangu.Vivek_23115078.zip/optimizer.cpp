#include "optimizer.h"

std::string optimizeTAC(const std::string& tac) {
    return "t2 = MIXDIVADD a b c";
}