#include <iostream>
#include "lexer.h"
#include "parser.h"
#include "tac.h"
#include "optimizer.h"
#include "codegen.h"

int main() {
    std::string input;
    std::cout << "Enter expression (e.g., a + b / c): ";
    std::getline(std::cin, input);

    auto tokens = tokenize(input);
    std::cout << "\nTokens:\n";
    for (const auto& t : tokens) std::cout << t << " ";
    std::cout << "\n";

    auto ast = parse(tokens);
    std::cout << "\nParse Tree (simulated):\n" << ast << "\n";

    auto tac = generateTAC(ast);
    std::cout << "\nThree Address Code:\n" << tac << "\n";

    auto optimized = optimizeTAC(tac);
    std::cout << "\nOptimized Instructions:\n" << optimized << "\n";

    auto asmcode = generateAssembly(optimized);
    std::cout << "\nCustom Assembly:\n" << asmcode << "\n";

    return 0;
}