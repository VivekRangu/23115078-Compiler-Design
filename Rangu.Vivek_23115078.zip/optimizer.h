#pragma once
#include <string>

std::string optimizeTAC(const std::string& tac);