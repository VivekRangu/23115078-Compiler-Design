#include "lexer.h"
#include <cctype>

std::vector<std::string> tokenize(const std::string& input) {
    std::vector<std::string> tokens;
    for (char c : input) {
        if (std::isspace(c)) continue;
        if (std::isalpha(c)) tokens.push_back(std::string(1, c));
        else if (c == '+' || c == '-' || c == '*' || c == '/') tokens.push_back(std::string(1, c));
    }
    return tokens;
}