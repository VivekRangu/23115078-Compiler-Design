#pragma once
#include <string>

std::string generateTAC(const std::string& ast);