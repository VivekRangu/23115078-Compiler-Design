#include "parser.h"

std::string parse(const std::vector<std::string>& tokens) {
    // Simulated parse tree for simplicity
    return "EXPR -> VAR + VAR / VAR";
}