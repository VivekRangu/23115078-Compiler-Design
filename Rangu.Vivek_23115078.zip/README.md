# C++ Expression Compiler (a + b / c)

This is a basic C++ compiler for parsing and compiling arithmetic expressions like `a + b / c`.
It includes all compilation phases: lexical analysis, parsing, intermediate code generation, optimization, and custom instruction generation.

## Features
- Parses expressions with +, -, *, /
- Supports variables (single letter)
- Generates Three Address Code (TAC)
- Optimizes instructions
- Emits custom instructions (e.g., MIXDIVADD for a + b / c)

## Custom Instruction
For `a + b / c`, the custom instruction is:
```
MIXDIVADD a b c -> (a + b / c)
```

## How to Build and Run

### Requirements
- g++ (GNU C++ Compiler)

### Build
```bash
g++ main.cpp lexer.cpp parser.cpp tac.cpp optimizer.cpp codegen.cpp -o compiler
```

### Run
```bash
./compiler
```

### Sample Input (when prompted):
```
a + b / c
```

## Output
- Tokens
- Parse Tree (simulated)
- Three Address Code (TAC)
- Optimized Instructions
- Custom Assembly

## GitHub (Optional)
[GitHub Repository](https://github.com/example/repo) (placeholder)