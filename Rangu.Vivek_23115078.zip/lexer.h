#pragma once
#include <vector>
#include <string>

std::vector<std::string> tokenize(const std::string& input);