#pragma once
#include <string>

std::string generateAssembly(const std::string& instructions);