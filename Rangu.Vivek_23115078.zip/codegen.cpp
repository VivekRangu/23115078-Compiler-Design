#include "codegen.h"

std::string generateAssembly(const std::string& instructions) {
    return "LOAD a\nLOAD b\nLOAD c\nMIXDIVADD a b c\nSTORE t2";
}