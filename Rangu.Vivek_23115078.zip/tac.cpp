#include "tac.h"

std::string generateTAC(const std::string& ast) {
    return "t1 = b / c\nt2 = a + t1";
}